export interface Category {
  id: number;
  name: string;
  description?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Supplier {
  id: number;
  name: string;
  contact: string;
  location: string;
  createdAt: string;
  updatedAt: string;
}

export interface Product {
  id: number;
  name: string;
  unit: string;
  categoryId?: number;
  category?: Category;
  prices?: Price[];
  createdAt: string;
  updatedAt: string;
}

export interface Price {
  id: number;
  productId: number;
  supplierId: number;
  price: number;
  supplier?: Supplier;
  updatedByUser?: {
    id: number;
    username: string;
  };
  createdAt: string;
  updatedAt: string;
}

export interface CreateProductRequest {
  name: string;
  unit: string;
  categoryId?: number;
}

export interface CreatePriceRequest {
  productId: number;
  supplierId: number;
  price: number;
}

export interface CreateSupplierRequest {
  name: string;
  contact: string;
  location: string;
}

export interface CreateCategoryRequest {
  name: string;
  description?: string;
}