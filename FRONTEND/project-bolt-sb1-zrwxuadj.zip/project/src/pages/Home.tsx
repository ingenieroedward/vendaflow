import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, Filter, RefreshCw, Package, TrendingUp } from 'lucide-react';
import { useProductStore } from '../store/productStore';
import SearchBar from '../components/features/SearchBar';
import ProductCard from '../components/features/ProductCard';
import Pagination from '../components/features/Pagination';
import LoadingSpinner from '../components/ui/LoadingSpinner';
import ErrorMessage from '../components/ui/ErrorMessage';
import Button from '../components/ui/Button';

const Home: React.FC = () => {
  const navigate = useNavigate();
  const { 
    products, 
    loading, 
    error, 
    pagination, 
    searchQuery, 
    getProducts, 
    clearError 
  } = useProductStore();

  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    if (!searchQuery) {
      getProducts();
    }
  }, []);

  const handleRefresh = () => {
    if (searchQuery) {
      // If there's a search query, clear it and reload all products
      window.location.reload();
    } else {
      getProducts(pagination.page);
    }
  };

  const handlePageChange = (page: number) => {
    getProducts(page, pagination.limit);
  };

  const handleProductClick = (productId: number) => {
    navigate(`/products/${productId}`);
  };

  const handleSearchResultClick = (productId: number) => {
    navigate(`/products/${productId}`);
  };

  const showSearchResults = searchQuery.trim().length > 0;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              Sistema de Gestión JJLM
            </h1>
            <p className="text-lg text-gray-600">
              Busca y compara precios de productos en tiempo real
            </p>
          </div>

          {/* Search Bar */}
          <div className="mb-6">
            <SearchBar
              placeholder="Buscar productos por nombre, categoría o proveedor..."
              onResultClick={handleSearchResultClick}
              autoFocus
            />
          </div>

          {/* Actions */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center space-y-4 sm:space-y-0">
            <div className="flex items-center space-x-3">
              <Button
                variant="outline"
                icon={RefreshCw}
                onClick={handleRefresh}
                size="sm"
              >
                Actualizar
              </Button>
              <Button
                variant="outline"
                icon={Filter}
                onClick={() => setShowFilters(!showFilters)}
                size="sm"
              >
                Filtros
              </Button>
            </div>

            <div className="flex items-center space-x-3">
              <Button
                variant="primary"
                icon={Plus}
                onClick={() => navigate('/products/new')}
                size="sm"
              >
                Nuevo Producto
              </Button>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        {!showSearchResults && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
              <div className="flex items-center">
                <Package className="w-8 h-8 text-blue-600 mr-3" />
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Productos</p>
                  <p className="text-2xl font-bold text-gray-900">{pagination.total}</p>
                </div>
              </div>
            </div>
            <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
              <div className="flex items-center">
                <TrendingUp className="w-8 h-8 text-green-600 mr-3" />
                <div>
                  <p className="text-sm font-medium text-gray-600">Con Precios</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {products.filter(p => p.prices && p.prices.length > 0).length}
                  </p>
                </div>
              </div>
            </div>
            <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
              <div className="flex items-center">
                <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center mr-3">
                  <span className="text-orange-600 font-bold">%</span>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-600">Cobertura</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {pagination.total > 0 
                      ? Math.round((products.filter(p => p.prices && p.prices.length > 0).length / pagination.total) * 100)
                      : 0
                    }%
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Error Message */}
        {error && (
          <ErrorMessage
            message={error}
            onDismiss={clearError}
            onRetry={handleRefresh}
            className="mb-6"
          />
        )}

        {/* Content */}
        <div className="space-y-6">
          {loading ? (
            <div className="flex justify-center items-center py-16">
              <LoadingSpinner size="lg" />
            </div>
          ) : (
            <>
              {/* Results Header */}
              {(products.length > 0 || showSearchResults) && (
                <div className="flex justify-between items-center">
                  <h2 className="text-xl font-semibold text-gray-900">
                    {showSearchResults ? 'Resultados de búsqueda' : 'Productos'}
                    <span className="text-gray-500 font-normal ml-2">
                      ({showSearchResults ? products.length : pagination.total})
                    </span>
                  </h2>
                </div>
              )}

              {/* Products Grid */}
              {products.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {products.map((product) => (
                    <ProductCard
                      key={product.id}
                      product={product}
                      onClick={() => handleProductClick(product.id)}
                    />
                  ))}
                </div>
              ) : !loading && (
                <div className="text-center py-16">
                  <Package className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    {showSearchResults ? 'No se encontraron productos' : 'No hay productos'}
                  </h3>
                  <p className="text-gray-500 mb-6">
                    {showSearchResults 
                      ? 'Intenta con otros términos de búsqueda'
                      : 'Comienza agregando tu primer producto'
                    }
                  </p>
                  {!showSearchResults && (
                    <Button
                      variant="primary"
                      icon={Plus}
                      onClick={() => navigate('/products/new')}
                    >
                      Agregar Producto
                    </Button>
                  )}
                </div>
              )}

              {/* Pagination */}
              {!showSearchResults && products.length > 0 && (
                <Pagination
                  pagination={pagination}
                  onPageChange={handlePageChange}
                  className="mt-8"
                />
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default Home;