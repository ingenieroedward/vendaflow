import React, { useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Package, Tag, Calendar, Edit, TrendingUp } from 'lucide-react';
import { useProductStore } from '../store/productStore';
import PriceTable from '../components/features/PriceTable';
import LoadingSpinner from '../components/ui/LoadingSpinner';
import ErrorMessage from '../components/ui/ErrorMessage';
import Button from '../components/ui/Button';
import { formatDateShort, formatCurrency } from '../utils/helpers';

const ProductDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { 
    currentProduct: product, 
    prices, 
    loading, 
    error, 
    getProductById, 
    getPricesByProduct,
    clearError,
    clearCurrentProduct 
  } = useProductStore();

  useEffect(() => {
    if (id) {
      const productId = parseInt(id, 10);
      getProductById(productId);
      getPricesByProduct(productId);
    }

    return () => {
      clearCurrentProduct();
    };
  }, [id]);

  const handleBack = () => {
    navigate('/');
  };

  const handleEdit = () => {
    navigate(`/products/${id}/edit`);
  };

  const handleAddPrice = () => {
    navigate(`/prices/new?productId=${id}`);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex justify-center items-center py-16">
            <LoadingSpinner size="lg" />
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <ErrorMessage
            message={error}
            onDismiss={clearError}
            onRetry={() => id && getProductById(parseInt(id, 10))}
          />
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center py-16">
            <Package className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              Producto no encontrado
            </h3>
            <p className="text-gray-500 mb-6">
              El producto que buscas no existe o ha sido eliminado
            </p>
            <Button variant="primary" onClick={handleBack}>
              Volver al inicio
            </Button>
          </div>
        </div>
      </div>
    );
  }

  const lowestPrice = prices.length > 0 ? Math.min(...prices.map(p => p.price)) : 0;
  const highestPrice = prices.length > 0 ? Math.max(...prices.map(p => p.price)) : 0;
  const averagePrice = prices.length > 0 ? prices.reduce((sum, p) => sum + p.price, 0) / prices.length : 0;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <Button
            variant="ghost"
            icon={ArrowLeft}
            onClick={handleBack}
            className="mb-4"
          >
            Volver
          </Button>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between">
              <div className="flex items-start space-x-4 mb-6 lg:mb-0">
                <div className="w-16 h-16 bg-blue-100 rounded-xl flex items-center justify-center">
                  <Package className="w-8 h-8 text-blue-600" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-gray-900 mb-2">
                    {product.name}
                  </h1>
                  <div className="flex flex-wrap items-center gap-4 text-sm text-gray-500">
                    <div className="flex items-center">
                      <Tag className="w-4 h-4 mr-1" />
                      <span>{product.unit}</span>
                    </div>
                    {product.category && (
                      <div className="flex items-center">
                        <span>•</span>
                        <span className="ml-1">{product.category.name}</span>
                      </div>
                    )}
                    <div className="flex items-center">
                      <Calendar className="w-4 h-4 mr-1" />
                      <span>Actualizado {formatDateShort(product.updatedAt)}</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-3">
                <Button
                  variant="outline"
                  icon={Edit}
                  onClick={handleEdit}
                  size="sm"
                >
                  Editar
                </Button>
                <Button
                  variant="primary"
                  icon={TrendingUp}
                  onClick={handleAddPrice}
                  size="sm"
                >
                  Agregar Precio
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Price Stats */}
        {prices.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Proveedores</p>
                  <p className="text-2xl font-bold text-gray-900">{prices.length}</p>
                </div>
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Package className="w-5 h-5 text-blue-600" />
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Menor Precio</p>
                  <p className="text-2xl font-bold text-green-600">{formatCurrency(lowestPrice)}</p>
                </div>
                <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                  <TrendingUp className="w-5 h-5 text-green-600" />
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Mayor Precio</p>
                  <p className="text-2xl font-bold text-red-600">{formatCurrency(highestPrice)}</p>
                </div>
                <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                  <TrendingUp className="w-5 h-5 text-red-600 transform rotate-180" />
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Precio Promedio</p>
                  <p className="text-2xl font-bold text-blue-600">{formatCurrency(averagePrice)}</p>
                </div>
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  <span className="text-blue-600 font-bold text-sm">Ø</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Prices Table */}
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold text-gray-900">
              Precios por Proveedor
            </h2>
            <Button
              variant="primary"
              icon={TrendingUp}
              onClick={handleAddPrice}
              size="sm"
            >
              Agregar Precio
            </Button>
          </div>

          <PriceTable prices={prices} />
        </div>

        {/* Product Info */}
        {product.category?.description && (
          <div className="mt-8">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">
                Información de Categoría
              </h3>
              <p className="text-gray-600">{product.category.description}</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductDetail;