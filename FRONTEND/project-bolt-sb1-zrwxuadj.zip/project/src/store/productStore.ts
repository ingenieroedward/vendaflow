import { create } from 'zustand';
import { Product, Price, PaginationInfo } from '../types';
import { productService } from '../services/products';

interface ProductState {
  products: Product[];
  currentProduct: Product | null;
  prices: Price[];
  loading: boolean;
  error: string | null;
  pagination: PaginationInfo;
  searchQuery: string;
  
  // Actions
  searchProducts: (query: string) => Promise<void>;
  getProducts: (page?: number, limit?: number) => Promise<void>;
  getProductById: (id: number) => Promise<void>;
  getPricesByProduct: (productId: number) => Promise<void>;
  setSearchQuery: (query: string) => void;
  clearError: () => void;
  clearCurrentProduct: () => void;
}

export const useProductStore = create<ProductState>((set, get) => ({
  products: [],
  currentProduct: null,
  prices: [],
  loading: false,
  error: null,
  pagination: {
    total: 0,
    page: 1,
    limit: 10,
    totalPages: 0,
  },
  searchQuery: '',

  searchProducts: async (query: string) => {
    if (!query.trim()) {
      set({ products: [] });
      return;
    }

    set({ loading: true, error: null });
    try {
      const products = await productService.searchProducts(query);
      set({ products, loading: false });
    } catch (error: any) {
      set({ error: error.message, loading: false });
    }
  },

  getProducts: async (page = 1, limit = 10) => {
    set({ loading: true, error: null });
    try {
      const response = await productService.getProducts(page, limit);
      set({
        products: response.data,
        pagination: response.pagination,
        loading: false,
      });
    } catch (error: any) {
      set({ error: error.message, loading: false });
    }
  },

  getProductById: async (id: number) => {
    set({ loading: true, error: null });
    try {
      const product = await productService.getProductById(id);
      set({ currentProduct: product, loading: false });
    } catch (error: any) {
      set({ error: error.message, loading: false });
    }
  },

  getPricesByProduct: async (productId: number) => {
    set({ loading: true, error: null });
    try {
      const prices = await productService.getPricesByProduct(productId);
      set({ prices, loading: false });
    } catch (error: any) {
      set({ error: error.message, loading: false });
    }
  },

  setSearchQuery: (query: string) => {
    set({ searchQuery: query });
  },

  clearError: () => {
    set({ error: null });
  },

  clearCurrentProduct: () => {
    set({ currentProduct: null, prices: [] });
  },
}));