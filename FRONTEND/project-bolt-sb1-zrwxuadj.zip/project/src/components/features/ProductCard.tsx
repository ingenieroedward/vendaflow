import React from 'react';
import { Package, MapPin, Calendar, TrendingUp } from 'lucide-react';
import { Product } from '../../types';
import { formatCurrency, formatDateShort } from '../../utils/helpers';

interface ProductCardProps {
  product: Product;
  onClick?: () => void;
  showPrices?: boolean;
}

const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onClick,
  showPrices = true,
}) => {
  const lowestPrice = product.prices?.reduce((min, price) => 
    !min || price.price < min ? price.price : min, 0
  );
  
  const highestPrice = product.prices?.reduce((max, price) => 
    !max || price.price > max ? price.price : max, 0
  );

  const pricesCount = product.prices?.length || 0;

  return (
    <div
      onClick={onClick}
      className={`bg-white rounded-lg border border-gray-200 p-6 transition-all duration-200 hover:shadow-md hover:border-blue-300 ${
        onClick ? 'cursor-pointer' : ''
      }`}
    >
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
            <Package className="w-6 h-6 text-blue-600" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-900">{product.name}</h3>
            <div className="flex items-center space-x-2 text-sm text-gray-500">
              <span>{product.unit}</span>
              {product.category && (
                <>
                  <span>•</span>
                  <span>{product.category.name}</span>
                </>
              )}
            </div>
          </div>
        </div>
        
        <div className="text-right">
          <div className="flex items-center text-sm text-gray-500">
            <Calendar className="w-4 h-4 mr-1" />
            {formatDateShort(product.updatedAt)}
          </div>
        </div>
      </div>

      {showPrices && (
        <div className="space-y-3">
          {pricesCount > 0 ? (
            <>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-700">
                  {pricesCount} proveedor{pricesCount !== 1 ? 'es' : ''}
                </span>
                <div className="flex items-center text-green-600">
                  <TrendingUp className="w-4 h-4 mr-1" />
                  <span className="text-sm font-medium">Precios disponibles</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-green-50 rounded-lg p-3">
                  <p className="text-xs text-green-600 font-medium uppercase">Menor precio</p>
                  <p className="text-lg font-bold text-green-700">
                    {formatCurrency(lowestPrice || 0)}
                  </p>
                </div>
                <div className="bg-blue-50 rounded-lg p-3">
                  <p className="text-xs text-blue-600 font-medium uppercase">Mayor precio</p>
                  <p className="text-lg font-bold text-blue-700">
                    {formatCurrency(highestPrice || 0)}
                  </p>
                </div>
              </div>

              {product.prices && product.prices.length > 0 && (
                <div className="space-y-2">
                  <p className="text-sm font-medium text-gray-700">Proveedores recientes:</p>
                  <div className="space-y-1">
                    {product.prices.slice(0, 3).map((price) => (
                      <div key={price.id} className="flex items-center justify-between text-sm">
                        <div className="flex items-center space-x-2">
                          <MapPin className="w-3 h-3 text-gray-400" />
                          <span className="text-gray-600">{price.supplier?.name}</span>
                        </div>
                        <span className="font-medium text-gray-900">
                          {formatCurrency(price.price)}
                        </span>
                      </div>
                    ))}
                    {(product.prices.length > 3) && (
                      <p className="text-xs text-gray-500 text-center">
                        +{product.prices.length - 3} más...
                      </p>
                    )}
                  </div>
                </div>
              )}
            </>
          ) : (
            <div className="bg-gray-50 rounded-lg p-4 text-center">
              <p className="text-sm text-gray-500">Sin precios registrados</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default ProductCard;