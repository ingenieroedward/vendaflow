import React, { useState, useEffect } from 'react';
import { Search, X } from 'lucide-react';
import { useProductStore } from '../../store/productStore';
import { debounce } from '../../utils/helpers';
import { DEBOUNCE_DELAY } from '../../utils/constants';

interface SearchBarProps {
  placeholder?: string;
  autoFocus?: boolean;
  onResultClick?: (productId: number) => void;
}

const SearchBar: React.FC<SearchBarProps> = ({
  placeholder = 'Buscar productos...',
  autoFocus = false,
  onResultClick,
}) => {
  const { searchQuery, setSearchQuery, searchProducts, products, loading } = useProductStore();
  const [localQuery, setLocalQuery] = useState(searchQuery);
  const [showResults, setShowResults] = useState(false);

  // Debounced search function
  const debouncedSearch = debounce((query: string) => {
    setSearchQuery(query);
    if (query.trim()) {
      searchProducts(query);
      setShowResults(true);
    } else {
      setShowResults(false);
    }
  }, DEBOUNCE_DELAY);

  useEffect(() => {
    debouncedSearch(localQuery);
  }, [localQuery]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setLocalQuery(e.target.value);
  };

  const handleClear = () => {
    setLocalQuery('');
    setSearchQuery('');
    setShowResults(false);
  };

  const handleResultClick = (productId: number) => {
    setShowResults(false);
    onResultClick?.(productId);
  };

  const handleInputFocus = () => {
    if (localQuery.trim() && products.length > 0) {
      setShowResults(true);
    }
  };

  const handleInputBlur = () => {
    // Delay hiding results to allow clicking on them
    setTimeout(() => setShowResults(false), 200);
  };

  return (
    <div className="relative w-full max-w-2xl mx-auto">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
        <input
          type="text"
          value={localQuery}
          onChange={handleInputChange}
          onFocus={handleInputFocus}
          onBlur={handleInputBlur}
          placeholder={placeholder}
          autoFocus={autoFocus}
          className="w-full pl-10 pr-10 py-3 text-lg border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 shadow-sm"
        />
        {localQuery && (
          <button
            onClick={handleClear}
            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
          >
            <X className="w-5 h-5" />
          </button>
        )}
        {loading && (
          <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
            <div className="animate-spin w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full" />
          </div>
        )}
      </div>

      {/* Search Results */}
      {showResults && localQuery.trim() && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-gray-200 rounded-lg shadow-lg max-h-96 overflow-y-auto z-50">
          {products.length > 0 ? (
            <div className="py-2">
              {products.map((product) => (
                <button
                  key={product.id}
                  onClick={() => handleResultClick(product.id)}
                  className="w-full px-4 py-3 text-left hover:bg-gray-50 transition-colors duration-150"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-medium text-gray-900">{product.name}</h4>
                      <p className="text-sm text-gray-500">
                        {product.unit} {product.category && `• ${product.category.name}`}
                      </p>
                    </div>
                    {product.prices && product.prices.length > 0 && (
                      <div className="text-right">
                        <p className="text-sm font-medium text-green-600">
                          {product.prices.length} precio{product.prices.length !== 1 ? 's' : ''}
                        </p>
                      </div>
                    )}
                  </div>
                </button>
              ))}
            </div>
          ) : (
            <div className="px-4 py-6 text-center text-gray-500">
              <Search className="w-8 h-8 mx-auto mb-2 text-gray-300" />
              <p>No se encontraron productos</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default SearchBar;